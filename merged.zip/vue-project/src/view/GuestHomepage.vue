<template>
  <v-app>
    <!-- Main Content -->
    <v-main class="bg-grey-lighten-3 px-2">
      <v-container fluid>
        <!-- Section Title -->
        <v-row justify="center" class="mt-8 ml-4 mb-4">
          <v-col cols="12" md="8" class="text-center">
            <h1 class="font-weight-bold mb-2" style="font-family: 'Playfair Display', serif; font-size: 2.5rem;">
              Welcome to our Barangay Online Services
            </h1>
            <div class="mx-auto my-4" style="width: 80px; height: 6px; background: #3b82f6; border-radius: 8px;"></div>
            <h2 class="font-weight-semibold mb-2" style="font-family: 'Playfair Display', serif; font-size: 1.5rem;">
              Barangay Sta. Cruz
            </h2>
            <p class="text-grey-darken-1" style="font-family: 'Poppins', sans-serif;">
              Effortless Access, One Click Away: Barangay Sta. Cruz Launches Online Services for Seamless Barangay
              Certification
            </p>
          </v-col>
        </v-row>

        <!-- Service Cards -->
        <v-row justify="center" class="mt-6">
         

          <!-- Event Scheduling -->
          <v-col cols="12" md="4"  class="d-flex align-stretch">
            <v-card class="service-card"
              :style="`background-image: linear-gradient(to bottom, rgba(30,64,175,0.4), rgba(30,64,175,0.8)), url('https://readdy.ai/api/search-image?query=community%20event%20planning%2C%20calendar%20and%20event%20organization%20tools%2C%20people%20planning%20events%20together%2C%20professional%20setting%20with%20blue%20tint&width=400&height=320&seq=2&orientation=landscape'); background-size: cover; background-position: center;`"
              elevation="8" rounded="xl">
              <v-card-text class="d-flex flex-column align-center justify-center h-100 service-card-content">
                <div class="d-flex align-center justify-center mb-4"
                  style="background:rgba(255,255,255,0.15); border-radius:50%; width:80px; height:80px;">
                  <v-icon color="white" size="48">mdi-calendar-outline</v-icon>
                </div>
                <div class="text-h5 font-weight-bold text-white mb-2">Event Scheduling</div>
                <div class="text-white text-center mb-4">Schedule and manage community events with ease</div>
                <v-btn color="yellow-darken-2" variant="outlined" class="text-white mb-8 font-weight-medium"
                  style="background:rgba(255,255,255,0.12);">Book Now</v-btn>
              </v-card-text>
            </v-card>
          </v-col>

          <!-- Submit Complaints -->
          <v-col cols="12" md="4" class="d-flex align-stretch">
            <v-card class="service-card"
              :style="`background-image: linear-gradient(to bottom, rgba(30,64,175,0.4), rgba(30,64,175,0.8)), url('https://readdy.ai/api/search-image?query=complaint%20submission%20system%2C%20digital%20form%20filling%2C%20community%20feedback%20interface%2C%20professional%20setting%20with%20blue%20tint&width=400&height=320&seq=3&orientation=landscape'); background-size: cover; background-position: center;`"
              elevation="8" rounded="xl">
              <v-card-text class="d-flex flex-column align-center justify-center h-100 service-card-content">
                <div class="d-flex align-center justify-center mb-4"
                  style="background:rgba(255,255,255,0.15); border-radius:50%; width:80px; height:80px;">
                  <v-icon color="white" size="48">mdi-file-document-outline</v-icon>
                </div>
                <div class="text-h5 font-weight-bold text-white mb-2">Submit Complaints</div>
                <div class="text-white text-center mb-4">Voice your concerns through our digital complaint system</div>
                <v-btn color="yellow-darken-2" variant="outlined" class="text-white mb-8 font-weight-medium"
                  style="background:rgba(255,255,255,0.12);">File Now</v-btn>
              </v-card-text>
            </v-card>
          </v-col>
        </v-row>
      </v-container>
    </v-main>
  </v-app>
</template>

<style scoped>
.v-col.d-flex {
  display: flex;
  align-items: stretch;
}

.service-card {
  flex: 1;
  height: 100%;
  transition: transform 0.3s;
  cursor: pointer;
}

.service-card:hover {
  transform: translateY(-5px) scale(1.02);
  box-shadow: 0 10px 32px 0 rgba(30, 64, 175, 0.18);
}

.service-card-content {
  position: relative;
  z-index: 2;
}
</style>
