<script setup>
</script>

<template>
  <header>

  </header>

  <main>
    <router-view />
  </main>
</template>

<style scoped>
/* Optional styles */
</style>
